import { Component } from '@angular/core';
import { CommonModule, UpperCasePipe } from '@angular/common';
import { Observable, map } from 'rxjs';
import { ApiService } from '../../services/helpdesk.service';
import { TruncatePipe } from '../../pipes/truncate-pipe';

@Component({
  selector: 'app-home',
  standalone: true,
  templateUrl: './home.html',
  imports: [CommonModule, UpperCasePipe, TruncatePipe]
})
export class Home {
  posts$: Observable<any[]>;

  constructor(private api: ApiService) {
    this.posts$ = this.api.posts$.pipe(map(posts => posts.slice(0, 5)));
  }
}
