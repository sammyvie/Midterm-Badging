import { Component } from '@angular/core';
import { CommonModule, UpperCasePipe } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { BehaviorSubject, combineLatest, Observable, map } from 'rxjs';
import { ApiService } from '../../services/helpdesk.service';
import { TruncatePipe } from '../../pipes/truncate-pipe';

@Component({
  selector: 'app-services',
  standalone: true,
  templateUrl: './services.html',
  imports: [CommonModule, FormsModule, UpperCasePipe, TruncatePipe]
})
export class Services {
  search = '';
  search$ = new BehaviorSubject<string>('');
  posts$: Observable<any[]>;

  constructor(private api: ApiService) {
    this.posts$ = combineLatest([this.api.posts$, this.search$]).pipe(
      map(([posts, search]) =>
        posts.filter(post =>
          post.title.toLowerCase().includes(search.toLowerCase()) ||
          post.body.toLowerCase().includes(search.toLowerCase())
        )
      )
    );
  }

  // Fix: ngModelChange passes a string, not an Event
  onSearchChange(value: string) {
    this.search$.next(value);
  }
}
