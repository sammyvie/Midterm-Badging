import { Component } from '@angular/core';
import { CommonModule, UpperCasePipe } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { TruncatePipe } from '../../pipes/truncate-pipe';

@Component({
  selector: 'app-contact',
  standalone: true,
  templateUrl: './contact.html',
  imports: [CommonModule, FormsModule, UpperCasePipe, TruncatePipe]
})
export class Contact {
  form = { name: '', email: '', message: '' };
}
