import { FilterPostsPipe } from './filter-posts-pipe';

describe('FilterPostsPipe', () => {
  it('create an instance', () => {
    const pipe = new FilterPostsPipe();
    expect(pipe).toBeTruthy();
  });
});
